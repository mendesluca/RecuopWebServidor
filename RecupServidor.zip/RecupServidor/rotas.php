<?php

use Pecee\SimpleRouter\SimpleRouter as Router;
use App\Middleware\AuthMiddleware;

// Rota inicial para redirecionamento após login
Router::get('/RecupServidor/public', function() {
    session_start();
    if (isset($_SESSION['user'])) {
        if ($_SESSION['user'] === 'admin') {
            header('Location: /RecupServidor/public/feedbacks');
        } else {
            header('Location: /RecupServidor/public/formulario');
        }
    } else {
        header('Location: ../src/Views/login.view.php');
    }
});

// Rotas protegidas
Router::group(['prefix' => '/RecupServidor/public', 'middleware' => AuthMiddleware::class], function() {
    Router::get('/feedbacks', 'FeedbackController@index');
    Router::get('/feedbacks/{id}', 'FeedbackController@show');
    Router::post('/feedback/cadastrar', 'FeedbackController@store');
    Router::put('/feedback/atualizar', 'FeedbackController@update');
    Router::get('/logout', 'AuthController@logout');
});

// Rota pública para o formulário
Router::get('/RecupServidor/public/formulario', 'FeedbackController@create');

// Rota pública para login
Router::get('/RecupServidor/public/login', 'AuthController@login');
Router::post('/RecupServidor/public/login', 'AuthController@authenticate');