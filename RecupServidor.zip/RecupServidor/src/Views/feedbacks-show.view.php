<!DOCTYPE html>
<html>

<head>
    <title>Detalhes do Feedback</title>
</head>

<body>
    <h1>Detalhes do Feedback</h1>
    <p>ID: <?= $feedback['id'] ?></p>
    <p>Título: <?= $feedback['titulo'] ?></p>
    <p>Descrição: <?= $feedback['descricao'] ?></p>
    <p>Tipo: <?= $feedback['tipo'] ?></p>
    <p>Status: <?= $feedback['status'] ?></p>

    <a href="/feedbacks">Voltar</a>

    <form action="/feedback/atualizar" method="POST">
        <input type="hidden" name="id" value="<?= $feedback['id'] ?>">
        <label for="status">Status:</label>
        <select id="status" name="status" required>
            <option value="recebido">Recebido</option>
            <option value="em analise">Em Análise</option>
            <option value="em desenvolvimento">Em Desenvolvimento</option>
            <option value="finalizado">Finalizado</option>
        </select>
        <button type="submit">Atualizar Status</button>
    </form>
</body>

</html>