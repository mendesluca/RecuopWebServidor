<!DOCTYPE html>
<html>

<head>
    <title>Feedbacks</title>
</head>

<body>
    <h1>Lista de Feedbacks</h1>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Título</th>
                <th>Tipo</th>
                <th>Status</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($feedbacks as $feedback): ?>
            <tr>
                <td><?= $feedback['id'] ?></td>
                <td><?= $feedback['titulo'] ?></td>
                <td><?= $feedback['tipo'] ?></td>
                <td><?= $feedback['status'] ?></td>
                <td><a href="/feedbacks/<?= $feedback['id'] ?>">Detalhes</a></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>

</html>