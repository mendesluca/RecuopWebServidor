<!DOCTYPE html>
<html>

<head>
    <title>Cadastro de Feedback</title>
</head>

<body>
    <h1>Cadastro de Feedback</h1>
    <form action="/feedback/cadastrar" method="POST">
        <label for="titulo">Título:</label>
        <input type="text" id="titulo" name="titulo" required><br>

        <label for="descricao">Descrição:</label>
        <textarea id="descricao" name="descricao" required></textarea><br>

        <label for="tipo">Tipo:</label>
        <select id="tipo" name="tipo" required>
            <option value="bug">Bug</option>
            <option value="sugestao">Sugestão</option>
            <option value="reclamacao">Reclamação</option>
            <option value="feedback">Feedback</option>
        </select><br>

        <button type="submit">Enviar</button>
    </form>
</body>

</html>