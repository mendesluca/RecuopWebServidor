<?php

namespace App\Controllers;

class AuthController
{
    public function login()
    {
        require_once __DIR__ . '../Views/login.view.php';
    }

    public function authenticate()
    {
        $username = $_POST['username'];
        $password = $_POST['password'];

        if ($username === 'admin' && $password === '123456') {
            session_start();
            $_SESSION['user'] = 'admin';
            header('Location: /RecupServidor/public/feedbacks');
        } else {
            session_start();
            $_SESSION['user'] = 'regular';
            header('Location: /RecupServidor/public');
        }
    }

    public function logout()
    {
        session_start();
        session_destroy();
        header('Location: /RecupServidor/public/login');
    }
}