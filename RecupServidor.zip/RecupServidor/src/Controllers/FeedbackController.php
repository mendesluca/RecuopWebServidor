<?php

namespace App\Controllers;

use PDO;
use App\Models\Feedback;

class FeedbackController
{
    private $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    public function create()
    {
        require_once __DIR__ . '/../Views/formulario.view.php';
    }

    public function index()
    {
        $stmt = $this->pdo->query("SELECT * FROM feedbacks");
        $feedbacks = $stmt->fetchAll();
        require_once __DIR__ . '/../Views/feedbacks.view.php';
    }

    public function show($id)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM feedbacks WHERE id = ?");
        $stmt->execute([$id]);
        $feedback = $stmt->fetch();
        require_once __DIR__ . '/../Views/feedbacks-show.view.php';
    }

    public function store()
    {
        $titulo = $_POST['titulo'];
        $descricao = $_POST['descricao'];
        $tipo = $_POST['tipo'];

        $stmt = $this->pdo->prepare("INSERT INTO feedbacks (titulo, descricao, tipo) VALUES (?, ?, ?)");
        $stmt->execute([$titulo, $descricao, $tipo]);

        header('Location: /RecupServidor/public/feedbacks');
    }

    public function update()
    {
        parse_str(file_get_contents("php://input"), $_PUT);
        $id = $_PUT['id'];
        $status = $_PUT['status'];

        $stmt = $this->pdo->prepare("UPDATE feedbacks SET status = ? WHERE id = ?");
        $stmt->execute([$status, $id]);

        header('Location: /RecupServidor/public/feedbacks/' . $id);
    }
}

// Exemplo de utilização
$feedbackController = new FeedbackController($pdo);