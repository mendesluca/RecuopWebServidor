<?php

namespace App\Models;

class Feedback extends Conexao
{
    public function getAll()
    {
        $stmt = $this->pdo->query('SELECT * FROM feedbacks');
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById($id)
    {
        $stmt = $this->pdo->prepare('SELECT * FROM feedbacks WHERE id = :id');
        $stmt->execute(['id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function store($data)
    {
        $stmt = $this->pdo->prepare('INSERT INTO feedbacks (titulo, descricao, tipo, status) VALUES (:titulo, :descricao, :tipo, :status)');
        return $stmt->execute([
            'titulo' => $data['titulo'],
            'descricao' => $data['descricao'],
            'tipo' => $data['tipo'],
            'status' => 'recebido'
        ]);
    }

    public function updateStatus($id, $status)
    {
        $stmt = $this->pdo->prepare('UPDATE feedbacks SET status = :status WHERE id = :id');
        return $stmt->execute(['id' => $id, 'status' => $status]);
    }
}